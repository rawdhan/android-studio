package se.kth.mydiary1;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class loginActivity extends Activity {

    private Button LoginButton;
    private EditText UserEmail, password;
    private TextView NewAccountLink;
    private ProgressDialog loadingBar;

    private FirebaseAuth oAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        oAuth = FirebaseAuth.getInstance();



        UserEmail = (EditText) findViewById(R.id.login_Email);
        NewAccountLink = (TextView) findViewById(R.id.register_link);
        password = (EditText) findViewById(R.id.login_password);
        LoginButton = (Button) findViewById(R.id.login_button);
        loadingBar = new ProgressDialog(this);


        NewAccountLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SendUserToRegisterActivity();
            }
        });

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                AllowingUserToLogin();
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = oAuth.getCurrentUser();
        if (currentUser != null)
        {
            SendUserToMainActivity();
        }
    }


    private void AllowingUserToLogin()
    {
        String Email = UserEmail.getText().toString();
        String Password = password.getText().toString();

        if(TextUtils.isEmpty(Email))
        {
            Toast.makeText(this, "please write your Email..", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(Password))
        {
            Toast.makeText(this, "please write your Password..", Toast.LENGTH_SHORT).show();
        }
        else
        {
            loadingBar.setTitle("LogIn");
            loadingBar.setMessage("please wait, while w are Logging You Into Your Account...");
            loadingBar.show();
            loadingBar.setCanceledOnTouchOutside(true);

         oAuth.signInWithEmailAndPassword(Email,Password)
                 .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                     @Override
                     public void onComplete(@NonNull Task<AuthResult> task) {
                         if(task.isSuccessful())
                         {
                             SendUserToMainActivity();
                             Toast.makeText(loginActivity.this,"Your Are Logged In Successfully..",Toast.LENGTH_SHORT).show();
                             loadingBar.dismiss();
                         }
                         else
                         {
                             String message = task.getException().getMessage();
                             Toast.makeText(loginActivity.this,"Error Occured!! \n"+message,Toast.LENGTH_LONG).show();
                             loadingBar.dismiss();


                         }
                     }
                 });


        }
    }


    private void SendUserToMainActivity()
    {
        Intent mainIntent = new Intent(loginActivity.this, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(mainIntent);
        finish();
    }

    private void SendUserToRegisterActivity()
    {
        Intent registerIntent = new Intent(loginActivity.this, RegisterActivity.class);
        startActivity(registerIntent);


    }
}
