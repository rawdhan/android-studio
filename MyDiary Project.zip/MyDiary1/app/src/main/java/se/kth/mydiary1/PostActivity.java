package se.kth.mydiary1;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;


public class PostActivity extends Activity {

    private Toolbar mToolbar;
    private Button PostButton;
    private EditText NewDiary;

    private ProgressDialog loadingBar;

    private String CurrentUserID, post, saveCurrentDate,saveCurrentTime,postRandomName;

    private DatabaseReference PostRef;
    private DatabaseReference UserRef;
    private FirebaseAuth oAuth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        oAuth = FirebaseAuth.getInstance();

        CurrentUserID = oAuth.getCurrentUser().getUid();

        UserRef = FirebaseDatabase.getInstance().getReference().child("Users");
        PostRef = FirebaseDatabase.getInstance().getReference().child("Posts");

        PostButton = (Button)findViewById(R.id.Post_Button);
        NewDiary = (EditText) findViewById(R.id.new_diary);

        loadingBar = new ProgressDialog(this);


        mToolbar = (Toolbar) findViewById(R.id.post_Toolbar);
        setActionBar(mToolbar);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setDisplayShowHomeEnabled(true);
        getActionBar().setTitle("New Diary");


        PostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                PostFun();

            }
        });


            }

    private void PostFun()
    {
        Calendar calDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("dd-MMMM-yyyy");
        saveCurrentDate = currentDate.format(calDate.getTime());

        Calendar calTime = Calendar.getInstance();
        SimpleDateFormat currentTime = new SimpleDateFormat("  HH:mm");
        saveCurrentTime = currentTime.format(calTime.getTime());

        postRandomName = saveCurrentDate + saveCurrentTime;

        post = NewDiary.getText().toString();
        if(TextUtils.isEmpty(post))
        {
            Toast.makeText(this,"please write your Diary...",Toast.LENGTH_SHORT).show();

        }

        else
        {
            UserRef.child(CurrentUserID).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                {
                    if(dataSnapshot.exists()) {

                        String userFullname = dataSnapshot.child("Fullname").getValue().toString();
                        String UserName = dataSnapshot.child("Username").getValue().toString();

                        loadingBar.setTitle("Posting Your Diary");
                        loadingBar.setMessage("please wait, While we are Saving Your Post..");
                        loadingBar.show();
                        loadingBar.setCanceledOnTouchOutside(true);

                        HashMap PostMap = new HashMap();
                        PostMap.put("postcontent", post);
                        PostMap.put("date",saveCurrentDate);
                        PostMap.put("time",saveCurrentTime);
                        PostMap.put("fullname", userFullname);
                        PostMap.put("username", UserName);
                        PostMap.put("uid", CurrentUserID);


                        PostRef.child(CurrentUserID +" :: "+ postRandomName).updateChildren(PostMap).addOnCompleteListener(new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {

                                if (task.isSuccessful()) {

                                    SendUserToMainActivity();
                                    Toast.makeText(PostActivity.this, "Your Post is Created Successfully..", Toast.LENGTH_LONG).show();
                                    loadingBar.dismiss();

                                } else {
                                    String message = task.getException().getMessage();
                                    Toast.makeText(PostActivity.this, "Error Occured!! \n" + message, Toast.LENGTH_LONG).show();
                                    loadingBar.dismiss();
                                }

                            }
                        });
                    }
                    else
                    {
                        Toast.makeText(PostActivity.this,"Error Ouccred While Posting Your Diary",Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });



        }
    }


    private void SendUserToMainActivity()
    {
        Intent mainIntent = new Intent(PostActivity.this, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(mainIntent);
        finish();
    }


}
