package se.kth.mydiary1;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toolbar;


public class SettingsActivity extends Activity {

    private Toolbar mToolbar;
    private EditText Email,Username,OldPassword,NewPassword;
    private Button UpdateAccountSettingsButton;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);



        mToolbar = (Toolbar) findViewById(R.id.settings_toolbar);
        setActionBar(mToolbar);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setTitle("Account Settings");

        Email = (EditText) findViewById(R.id.settings_Email);
        Username = (EditText) findViewById(R.id.settings_username);
        OldPassword = (EditText) findViewById(R.id.settings_oldPassword);
        NewPassword = (EditText) findViewById(R.id.settings_newPassword);

        UpdateAccountSettingsButton = (Button) findViewById(R.id.settings_updateButton);




    }
}
