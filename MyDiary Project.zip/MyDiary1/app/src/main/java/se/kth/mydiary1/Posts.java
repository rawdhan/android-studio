package se.kth.mydiary1;

public class Posts
{
    public String uid, postcontent, date, time, fullname,username;

    public Posts()
    {}

    public Posts(String uid, String post, String date, String time, String fullname, String username) {
        this.uid = uid;
        this.postcontent = post;
        this.date = date;
        this.time = time;
        this.fullname = fullname;
        this.username = username;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPostcontent() {
        return postcontent;
    }

    public void setPost(String post) {
        post = post;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname   ;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
