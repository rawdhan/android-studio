package se.kth.mydiary1;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;


public class SetupActivity extends Activity {
    private EditText username , fullname;
    private Button SaveButton;
    private CircleImageView ProfileImage;
    private ProgressDialog loadingBar;

    private FirebaseAuth oAuth;
    private DatabaseReference UserRef;
    private StorageReference ProfileImageRef;

    String currentUserID;

    final static int Gallery_pick = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        oAuth = FirebaseAuth.getInstance();
        currentUserID = oAuth.getCurrentUser().getUid();
        UserRef = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID);
        ProfileImageRef = FirebaseStorage.getInstance().getReference().child("profile Images");

        username = (EditText) findViewById(R.id.Setup_username);
        fullname = (EditText) findViewById(R.id.Setup_fullname);
        SaveButton = (Button) findViewById(R.id.Setup_button);
        ProfileImage = (CircleImageView) findViewById(R.id.Setup_profileImage);
        loadingBar = new ProgressDialog(this);

        SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                SaveAccountSetUpInfo();

            }
        });

        ProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, Gallery_pick);

            }
        });

        UserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if(dataSnapshot.exists())
                {
                    if(dataSnapshot.hasChild("profileimage"))
                    {
                        String image = dataSnapshot.child("profileimage").getValue().toString();
                        Picasso.with(SetupActivity.this).load(image).placeholder(R.drawable.profile).into(ProfileImage);
                    }
                    else
                    {
                        Toast.makeText(SetupActivity.this, "please Selcet profile image first..",Toast.LENGTH_SHORT).show();
                    }





                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == Gallery_pick && resultCode==RESULT_OK && data!=null)
        {
            Uri ImageUri = data.getData();
            ProfileImage.setImageURI(ImageUri);

        }

        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if(resultCode==RESULT_OK)
            {
                Uri resultUri = result.getUri();

                StorageReference filePath = ProfileImageRef.child(currentUserID+ ".jpg");
                filePath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                        if(task.isSuccessful())
                        {
                            Toast.makeText(SetupActivity.this, "Your profile image stored successfylly..",Toast.LENGTH_SHORT).show();

                            final String downloadUrl = task.getResult().getStorage().getActiveDownloadTasks().toString();
                            UserRef.child("profileimage").setValue(downloadUrl)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                            if(task.isSuccessful())
                                            {
                                                Intent setUpIntent = new Intent(SetupActivity.this, SetupActivity.class);
                                                startActivity(setUpIntent);
                                                Toast.makeText(SetupActivity.this,"profile image stored to database successfully..",Toast.LENGTH_SHORT).show();
                                            }

                                            else
                                            {
                                                String message = task.getException().getMessage();
                                                Toast.makeText(SetupActivity.this, "Error Ouccred!! \n"+message, Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });

                        }
                    }
                });
            }

            else
            {
                Toast.makeText(this, "Error ouccred !!!!",Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void SaveAccountSetUpInfo()
    {
        String Username = username.getText().toString();
        String Fullname = fullname.getText().toString();

        if(TextUtils.isEmpty(Username))
        {
            Toast.makeText(this,"Please write your Username..",Toast.LENGTH_SHORT).show();

        }
        else if(TextUtils.isEmpty(Username))
        {
            Toast.makeText(this,"Please write your Fullname..",Toast.LENGTH_SHORT).show();

        }

        else
        {
            loadingBar.setTitle("Saving Information");
            loadingBar.setMessage("please wait, while w are Saving Your Information...");
            loadingBar.show();
            loadingBar.setCanceledOnTouchOutside(true);

            HashMap userMap = new HashMap();
            userMap.put("Username", Username);
            userMap.put("Fullname", Fullname);
            UserRef.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task)
                {

                    if(task.isSuccessful())
                    {

                        SendUserToMainActivity();
                        Toast.makeText(SetupActivity.this, "Your Information is Created Successfully..", Toast.LENGTH_LONG).show();
                        loadingBar.dismiss();

                    }

                    else
                    {
                        String message = task.getException().getMessage();
                        Toast.makeText(SetupActivity.this, "Error Occured!! \n"+message,Toast.LENGTH_LONG).show();
                        loadingBar.dismiss();
                    }

                }
            });


        }
    }

    private void SendUserToMainActivity()
    {
        Intent mainIntent = new Intent(SetupActivity.this, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(mainIntent);
        finish();
    }
}
